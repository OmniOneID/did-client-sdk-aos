/*
 * Copyright 2024 OmniOne.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.omnione.did.sdk.communication.urlconnection;

import org.omnione.did.sdk.communication.exception.CommunicationErrorCode;
import org.omnione.did.sdk.communication.exception.CommunicationException;
import org.omnione.did.sdk.communication.logger.CommunicationLogger;
import org.omnione.did.sdk.wallet.walletservice.logger.WalletLogger;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class HttpUrlConnectionTask {
    public HttpUrlConnectionTask(){

    }
    public String makeHttpRequest(String urlString, String method, String payload) throws CommunicationException {
        WalletLogger.getInstance().d("request : " + payload + " / " + urlString + " / [" + method + "]");

        if (urlString == null || urlString.isEmpty()) {
            throw new CommunicationException(CommunicationErrorCode.ERR_CODE_COMMUNICATION_INVALID_PARAMETER, "urlString");
        }
        if (method == null || method.isEmpty()) {
            throw new CommunicationException(CommunicationErrorCode.ERR_CODE_COMMUNICATION_INVALID_PARAMETER, "method");
        }

        HttpURLConnection urlConnection = null;
        try {
            URL url = new URL(urlString);
            urlConnection = (HttpURLConnection) url.openConnection();
            urlConnection.setRequestMethod(method);
            urlConnection.setReadTimeout(10000);
            urlConnection.setConnectTimeout(15000);
            urlConnection.setRequestProperty("Content-Type", "application/json");
            urlConnection.setRequestProperty("Accept", "application/json");

            if ("POST".equalsIgnoreCase(method)) {
                urlConnection.setDoOutput(true);
                try (OutputStream os = urlConnection.getOutputStream()) {
                    if (payload != null) {
                        byte[] input = payload.getBytes("utf-8");
                        os.write(input, 0, input.length);
                    }
                }
            }

            urlConnection.connect();
            int responseCode = urlConnection.getResponseCode();

            try (
                    InputStream is = (responseCode == HttpURLConnection.HTTP_OK)
                            ? urlConnection.getInputStream()
                            : (responseCode == HttpURLConnection.HTTP_BAD_REQUEST || responseCode == HttpURLConnection.HTTP_SERVER_ERROR)
                            ? urlConnection.getErrorStream()
                            : urlConnection.getInputStream();
                    InputStreamReader reader = new InputStreamReader(is, "utf-8");
                    BufferedReader in = new BufferedReader(reader)
            ) {
                StringBuilder result = new StringBuilder();
                String inputLine;
                while ((inputLine = in.readLine()) != null) {
                    result.append(inputLine);
                }

                if (responseCode == HttpURLConnection.HTTP_OK) {
                    WalletLogger.getInstance().d("response : " + result + " / " + responseCode);
                    return result.toString();
                } else if (responseCode == HttpURLConnection.HTTP_BAD_REQUEST || responseCode == HttpURLConnection.HTTP_SERVER_ERROR) {
                    throw new CommunicationException(CommunicationErrorCode.ERR_CODE_COMMUNICATION_SERVER_FAIL, result.toString());
                } else {
                    throw new CommunicationException(CommunicationErrorCode.ERR_CODE_COMMUNICATION_INCORRECT_URL_CONNECTION, urlString);
                }
            }

        } catch (IOException e) {
            throw new CommunicationException(CommunicationErrorCode.ERR_CODE_COMMUNICATION_INCORRECT_URL_CONNECTION, e.getMessage());
        } finally {
            if (urlConnection != null) {
                urlConnection.disconnect();
            }
        }
    }

}

